import argparse

def final_results():
    """
    function to present the summary of the three model architecture ran in tabular form.
    inputs: text file of the results. 
                     doc_1 = alexnet_pet-images.txt(default value)
                     doc_2 = resnet_pet-images.txt("")
                     
    Return:
             None
              
    """
    parser = argparse.ArgumentParser()
 
    # Create 3 command line arguments as mentioned above using add_argument() from ArguementParser method
    parser.add_argument('--doc_1', type = str, default = 'alexnet_pet-images.txt')
    parser.add_argument('--doc_2', type = str, default = 'resnet_pet-images.txt')
    parser.add_argument('--doc_3', type = str, default = 'vgg_pet-images.txt')
    doc_1 = parser.parse_args().doc_1
    doc_2 = parser.parse_args().doc_2
    doc_3 = parser.parse_args().doc_3
    
    #Extracts the names in a list
    doc_names = [doc_1, doc_2, doc_3]
   
    # This part presents the summary of the images in 
    with open(doc_names[0]) as result_file:
            line = result_file.readline()
            while line != "":
                if line[0:27] == "*** Results Summary for CNN":
                    print(result_file.readline())
                    print(result_file.readline())
                    print(result_file.readline())
             
                line = result_file.readline()
    # This part presents summary of the performances of the architectures            
    final_result_dic = {}  #dictionary to gather all values in one place
    word_doc_names = [] # This is to be used as the dictionary key
    for doc_name in doc_names:
        word_doc_name = str(doc_name.split('_')[0])
        final_result_dic[word_doc_name] = []
        word_doc_names.append(word_doc_name)
        
    for doc_name in doc_names:
        with open(doc_name, 'r') as result_file:
            line = result_file.readline()
            while line != "":
                if line[0:32] == "*** Results Summary(Percentages)":
                    i = 0
                    while i < 4:
                       line = result_file.readline()
                       
                       line = line.strip()
                       line = line.split(':')
                        
                       final_result_dic[str(doc_name.split('_')[0])].extend([float(line[1])])
                       
                       i += 1
                line = result_file.readline()
            
    print("{} | {} | {} | {} | {}".format('CNN Model Architecture', 
                                            '% Not-a-Dog Correct', 
                                            '% Dogs correct', 
                                            '% Breed correct', 
                                            '% match'))
    for word_doc_name in word_doc_names:
        print("{} | {} | {} | {} | {} ".format(word_doc_name, 
                                               final_result_dic[word_doc_name][3], 
                                               final_result_dic[word_doc_name][1], 
                                               final_result_dic[word_doc_name][2], 
                                               final_result_dic[word_doc_name][0]))                                                     
                                                             
final_results()                                                           
                                                             
                                                             
                    
                
   
        